# exec(open('/Users/cmueller/Downloads/germanmidtermmap/diodecapgrouper.py').read())

import pcbnew

board = pcbnew.GetBoard()

def find_module(ref):
    for fp in board.GetFootprints():
        if fp.GetReference() == ref:
            return fp
    return None

for i in range(226, 236):
    led_ref = f"D{i}"
    cap_ref = f"C{i}"

    led = find_module(led_ref)
    cap = find_module(cap_ref)

    if led and cap:
        # Move capacitor 10mm to the right of LED (bigger so you can see it)
        led_pos = led.GetPosition()
        led.SetPosition(pcbnew.VECTOR2I((i//20) * pcbnew.FromMM(5) - pcbnew.FromMM(30), (i%20) * pcbnew.FromMM(5)+pcbnew.FromMM(2)))
        cap.SetPosition(pcbnew.VECTOR2I((i//20) * pcbnew.FromMM(5) - pcbnew.FromMM(30), (i%20) * pcbnew.FromMM(5)))

        # Optional: match LED orientation
        cap.SetOrientation(led.GetOrientation())
    else:
        print(f"Warning: {led_ref} or {cap_ref} not found!")

# Refresh the board to see the changes
pcbnew.Refresh()