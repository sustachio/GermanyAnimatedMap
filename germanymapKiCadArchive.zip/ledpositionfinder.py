# exec(open('/Users/cmueller/Downloads/germanmidtermmap/ledpositionfinder.py').read())

import pcbnew

board = pcbnew.GetBoard()

def find_module(ref):
    for fp in board.GetFootprints():
        if fp.GetReference() == ref:
            return fp
    return None

for i in range(1, 236):
    led_ref = f"D{i}"

    led = find_module(led_ref)

    if led:
        led_pos = led.GetPosition()
          
        print(f"[{led_pos.x}, {led_pos.y}], ", end="")
    else:
        print(f"Warning: {led_ref} or {cap_ref} not found!")

# Refresh the board to see the changes
pcbnew.Refresh()